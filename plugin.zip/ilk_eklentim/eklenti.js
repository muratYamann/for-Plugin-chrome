chrome.browserAction.setBadgeText({text: String("kou")});
			
	