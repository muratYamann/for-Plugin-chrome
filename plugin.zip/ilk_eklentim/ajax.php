<?php
	require_once("vt_ayar.php");
	
	$metin = $_POST["deger"];
	$sorgu = mysql_query("INSERT INTO tbl_metin SET metin_text = '$metin'",$baglan);
	if ( $sorgu ){
		// veri tabanına yazma başarılı
		echo 1;
	}else{
		//veritabanına yazma başarısız
		echo mysql_Error();
	}
	
	
	
?>