<?php
	require_once("vt_ayar.php");
	
	$sorgu = mysql_query("SELECT * FROM tbl_metin ORDER BY metin_id DESC LIMIT 1",$baglan);
	
	if( mysql_affected_rows() ){
		$row = mysql_fetch_assoc($sorgu);
		
		$dizi = split('[.,:;"\'*-+/?!%&)(]',$row["metin_text"]); 
		foreach($dizi as $key=>$val){
			echo $val;
		}
	}else{
		echo "Veri bulunamadi.";
	}
	
?> 