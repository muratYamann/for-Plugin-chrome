<?php
	require_once("vt_ayar.php");
	
	$sorgu = mysql_query("SELECT * FROM tbl_metin ORDER BY metin_id DESC LIMIT 1",$baglan);
	
	if( mysql_affected_rows() ){
		$row = mysql_fetch_assoc($sorgu);
		
		$dizi = split('[.,:;"\'*-+/?!%&)( ]',$row["metin_text"]); 
		$dizi2[] = "";
		echo '<table border="0" padding="0" margin="0" style="padding:0;margin:0;font:12px Arial;">';
		foreach($dizi as $key=>$val){
			$varmi = 0;
			for ( $i = 0; $i < count($dizi2); $i++ ){
				if ( $val == $dizi2[$i] ){
					$varmi = 1;
					break;
				}
			}
			if ( $varmi )
				continue;
			
			$dizi2[] = $val;
			$frekans = 0;
			for ( $i = 0; $i < count($dizi); $i++ ){
				if ( $val == $dizi[$i] )
					$frekans++;
			}
			echo '<tr>';
				echo '<td width="100">"'.$val.'"</td><td>:'.$frekans." adet.</td>";
			echo '</tr>';
			
			
			
		}
		echo '</table>';
	}else{
		echo "veri bulunamadi.";
	}
	
?> 